

// init and import stuff
const express = require('express');
const app = express();
const http = require('http');
const server = http.createServer(app);
const { Server}  = require("socket.io");
const io = new Server(server);

	const morgan=require('morgan'); //automatically logs requests
	//const favicon = require('serve-favicon'); // for sending the favicon - does not work
	//const multer=require("multer"); // used for uploading files - not in use

	const nidapediaRouter = require("./router/nidapediaRoutes")

	// const express = require('express'); //EXPRESS IS LOVE
	// let app = express();				//EXPRESS IS LIFE

	app.set('views', './views')
	app.set('view engine', 'ejs')

	app.use(express.json()); //render jsons
	app.use(morgan('tiny')); //console.log every request with morgan preset 'tiny'
							//a more detailed requests would be with preset 'dev

	// This is the next handler for the above requested URL
	// Serve static resources from "public", if they exist
	app.use(express.static("static/styles"));
    app.use(express.static("static/images"))

	//Allows data types other than strings to be sent through request/response protocol
	app.use(express.urlencoded({extended: true}));


 // mongoose stuff
	const mongoose = require('mongoose'); // Require mongoose module
	mongoose.set('strictQuery', false); //do this for update purposes
	mongoose.connect('mongodb://127.0.0.1/nidaPedia', {useNewUrlParser: true}); //make database connection
	let db = mongoose.connection;
	let Opinion = require("./schemas/nidapediaSchemas")
	db.on('error',console.error.bind(console,'connectionerror:'));
	

app.get('/', (req, res)=>{
    res.render('index', {})
});

// This is a shorthand way of creating/initializing the HTTP server
server.listen(80,'0.0.0.0');
//app.listen(3000);
console.log("Server listening");