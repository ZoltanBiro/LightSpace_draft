const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const opinionSchema = Schema({
    author:String,
	opinion: String,
    target: String
    // upvotes?
    // downvotes?
});

// User model
const TestOpinion = mongoose.model('TestOpinion', {
    name: String,
    opinion:String,
    target:String
});


//to export our model "Opinion"
module.exports = mongoose.model("Opinion", opinionSchema,'nidapedia');