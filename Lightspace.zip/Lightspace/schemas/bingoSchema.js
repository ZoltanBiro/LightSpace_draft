const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const bingoSquareSchema = Schema({
    prompt:String
});


//to export our model "Opinion"
module.exports = mongoose.model("BingoSquare", bingoSquareSchema,'nidapedia');