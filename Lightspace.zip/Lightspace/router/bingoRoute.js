const express = require('express');

let router = express.Router();
router.use(express.urlencoded({extended: true}));

let BingoSquare = require("../schemas/bingoSchema")

router.get('/', (req, res)=>{
    res.render('bingo',{});
});





let bingoInput = new BingoSquare({
   prompt:"cut kole in 2"
});

bingoInput.save();