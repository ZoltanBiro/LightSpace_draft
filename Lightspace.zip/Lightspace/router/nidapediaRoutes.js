const express = require('express');



let router = express.Router();

const io = require("../server.js")


router.use(express.urlencoded({extended: true}));
//let Opinion = require("./schemas/nidapediaSchemas")




router.get('/', (req, res)=>{
    res.render('nidapedia',{opinions:{}});
});

router.post('/addOpinion', (req, res) => {
    // console.log("routed js");
	console.log("This guy's ip is ",req.ip);
	let Opinion = require("../schemas/nidapediaSchemas")
	
	 let message = new Opinion({
	 	opinion:req.body.message,
		target:"Nida",
		author:req.body.name
	});
	message.save();
	io.emit('server-message', "hi"); //--------------------------

	//let returnData;
	Opinion.find({}).then(data=>{
		//res.writeHead(200,{ "Content-Type": "application/json" });
		res.send(data);
		//res.send(JSON.stringify(data));
	});
	
});

router.get('/addOpinion', (req, res) => {
    // console.log("routed js");
	console.log("This guy's ip is ",req.ip);
	

	//let returnData;
	Opinion.find({}).then(data=>{
		//res.writeHead(200,{ "Content-Type": "application/json" });
		res.send(data);
		//res.send(JSON.stringify(data));
	});
	
});





module.exports = router;